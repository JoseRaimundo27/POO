public class Cliente{
  private String nome, cpf;

  public Cliente(String nome, String cpf){
    this.nome = nome;
    this.cpf = cpf;
  }

  public double getEmprestimoMaximo(){
    return 1000.0;
  }

  public String getNome(){
    return this.nome;
  }
}