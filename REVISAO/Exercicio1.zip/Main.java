import java.util.ArrayList;

class Main {
  public static void main(String[] args) {
    ArrayList<Cliente> clientes = new ArrayList();
    clientes.add(new Cliente("Pedro", "123"));
    clientes.add(new Empregado("José", "1234", 1000.0));
    clientes.add(new Chefe("Gabriel", "12345", 2000.0, 1.1));

    for (Cliente cliente : clientes){
      if (cliente instanceof Chefe){
        Chefe chefe = (Chefe) cliente;
        System.out.println("O salário de " + chefe.getNome() + " é " + chefe.getSalario() + " e o seu bônus é de " + chefe.getBonus());
      }
      else if (cliente instanceof Empregado){
        Empregado chefe = (Empregado) cliente;
        System.out.println("O salário de " + chefe.getNome() + " é " + chefe.getSalario());
      }
      System.out.println(cliente.getEmprestimoMaximo());
    }
  }
}