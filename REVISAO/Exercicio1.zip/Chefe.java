public class Chefe extends Empregado{
  private double bonus;

  public Chefe(String nome, String cpf, double salario, double bonus){
    super(nome, cpf, salario);
    this.bonus = bonus;
  }

  public double getEmprestimoMaximo(){
    return super.getEmprestimoMaximo() + this.bonus;
  }

  public double getBonus(){
    return this.bonus;
  }
}