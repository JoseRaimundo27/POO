public class Empregado extends Cliente{
  private double salario;

  public Empregado(String nome, String cpf, double salario){
    super(nome, cpf);
    this.salario = salario;
  }

  public double getEmprestimoMaximo(){
    return 2 * this.salario;
  }

  public double getSalario(){
    return this.salario;
  }
}