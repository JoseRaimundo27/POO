class Main {
  public static void main(String[] args) {
    ContaCorrente cc = new ContaCorrente("Pedro", 123, 0f, 500f);
    System.out.println("Saldo atual é " + cc.getSaldo());

    System.out.println("Saque 1000");
    cc.saque(1000f);
    System.out.println("Saldo atual é " + cc.getSaldo());
    System.out.println("Saque 1000");
    cc.deposito(1000f);
    System.out.println("Saldo atual é " + cc.getSaldo());
    System.out.println("Saque 750");
    cc.saque(750f);
    System.out.println("Saldo atual é " + cc.getSaldo());
    System.out.println("Saque 250");
    cc.saque(250f);
    System.out.println("Saldo atual é " + cc.getSaldo());

    ContaPoupanca cp = new ContaPoupanca("Pedro", 123, 0f, 0.1f);
    System.out.println("Saldo atual poupanca é " + cp.getSaldo());

    System.out.println("Saque 1000");
    cp.saque(1000f);
    System.out.println("Saldo atual poupanca é " + cp.getSaldo());
    System.out.println("Saque 1000");
    cp.deposito(1000f);
    System.out.println("Saldo atual poupanca é " + cp.getSaldo());
    System.out.println("Saque 250");
    cp.saque(250f);
    System.out.println("Saldo atual poupanca é " + cp.getSaldo());
    cp.correcaoMensal();
    System.out.println("Saldo atual poupanca é " + cp.getSaldo());
    //criar um menu para
    // 1. Abrir conta
    // 2. Fazer deposito
    // 3. Fazer saque
    // 4. Corrigir Mensal
  }
}