public class ContaCorrente extends Conta{
  private float limite;

  public ContaCorrente(String titular, int numero, float saldo, float limite){
    super(titular, numero, saldo);
    this.limite = limite;
  }

  public boolean saque(float valor){
      if (valor <= this.limite){
        return super.saque(valor);
      }
      System.out.println("Saque falhou! Limite invalido");
      return false;
    }
}