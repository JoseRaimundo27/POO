public class Conta{
private String titular;
private int numero;
private float saldo;

public Conta (){}
    public Conta(String titular, int numero, float saldo){
      this.titular = titular;
      this.numero = numero;
      this.saldo = saldo;
    }

    public boolean saque(float valor){
      if (valor <= this.saldo){
        this.saldo -= valor;
        System.out.println("Saque feito");
        return true;
      }
      System.out.println("Saque falhou! Saldo insuficiente");
      return false;
    }

    public boolean deposito(float valor){
        this.saldo += valor;
        return true;
    }

   public float getSaldo(){
      return this.saldo;
   }

  public void setSaldo(float valor){
      this.saldo = valor;
   }
}