public class ContaPoupanca extends Conta{
  private float indice;

  public ContaPoupanca(String titular, int numero, float saldo, float indice){
    super(titular, numero, saldo);
    this.indice = indice;
  }
  
  public boolean correcaoMensal() {
    this.setSaldo(this.getSaldo() * (1 + indice));
    return true;
  }
}