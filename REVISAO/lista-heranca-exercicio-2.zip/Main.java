import java.util.*;

class Main {
  public static void main(String[] arg)
    { 
        ArrayList <Funcionario> funcionarios = new ArrayList();
        Funcionario f = new Funcionario("Daniela","9033281922",(float)300.0);
        funcionarios.add(f);
        funcionarios.add(new Empacotador("Silvia","5833920117",(float)600.0,true));
        funcionarios.add(new Caixa("Diogo", "12345678910", (float)400.2));
        Caixa c = new Caixa("Jorge", "222", (float)500.2);
        // Funcionario não tem addHoraExtra
        c.addHoraExtra((float)10.5);
        funcionarios.add(c);
        for (Funcionario auxp: funcionarios ) {
              System.out.println(auxp); 
              System.out.println(auxp.calculaSalario());
              ///Codifiquem para o mostrar o calculo do salario
        }
    }
}